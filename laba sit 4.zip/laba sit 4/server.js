let express = require('express');
let app = express();
let prs = require('body-parser');
let fs = require('fs');
let studmas = [];
let day = new Date();
let k = 0;
let data = fs.readFileSync('std.json','utf8');
studmas = JSON.parse(data,null,'\t');

app.use(prs.json());


app.get('/students',function (req,res,next){
res.send(studmas);
next();
})

app.get('/students/:ind', function (req,res){
console.log(req.params);
let std = studmas.find(function(std){
return std.id === Number(req.params.ind)
})
res.send(std);
});



app.post('/students',(req,res)=>{
console.log('добавление пользователя');
let id = Math.max.apply(Math,studmas.map(function(o){return o.id;}))

let std = {
id:id+1,
age:req.body.age,
firstName:req.body.firstName,
lastName:req.body.lastName,
group:req.body.group,
createdAt:day,
updatedAT:day,
}
studmas.push(std);
res.send('ID = ' + std.id);
// запись в файл----------------------------—
let stdprs = JSON.stringify(studmas,null,'\t');
fs.writeFileSync('std.json', stdprs);
//--------------------------—

});

app.put('/students/:ind', function (req,res){
console.log('обновление пользователя');

let target = JSON.parse(data);
let std = target.find(function(std){
return std.id === Number(req.params.ind)
});
let mark = target.findIndex(std => std.id === Number(req.params.ind));
if (mark !== null) {
target[mark].firstName = req.body.firstName;
target[mark].lastName = req.body.lastName;
target[mark].age = req.body.age;
target[mark].group = req.body.group;
target[mark].updatedAT = new Date;

fs.writeFileSync("std.json", JSON.stringify(target,null,'\t'));
} else {
res.status(404).send('Данные не найдены');
}
res.send(target);
});

app.delete('/students/:ind', function (req,res){
console.log('удаление пользователя');
std = std.filter(function(std){
return std.id !== Number(req.params.ind)
});
res.sendSatus(200);
});


app.listen(3000);